using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TP10.Models;

namespace TP10.Controllers;

public class BackOfficeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public BackOfficeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult CrearPregunta()
    {
        List<Categoria> Cat = BD.ObtenerCategorias();
        ViewBag.Categorias = Cat;
        return View();
    }
    public IActionResult CrearPreguntaGuardar(int categoria, string enunciado, string c1, string p2, string p3, string p4)
    {
        BD.CrearPregunta(categoria, enunciado);
        int i = BD.ObtenerIDP(enunciado);

        BD.CrearRCorrecta(i, c1);

        List<string> l = new List<string> { p2, p3, p4 };

        for (int j = 1; j < 4 ; j++)
        {
            BD.CrearRIncorrecta(i, l[j - 1], j + 1);
        }

        return RedirectToAction("Index", "Home");
    }


}
