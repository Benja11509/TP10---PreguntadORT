using System.Collections.Generic;
using System.Linq;
using System.Web;
using TP10.Models;
using Newtonsoft.Json;


namespace TP10.Models
{
    public class Juego
    {
        [JsonProperty]
        public string Username { get; set; }
        [JsonProperty]
        public int PuntajeActual { get; set; }
        [JsonProperty]
        public int CantidadPreguntasCorrectas { get; set; }
        [JsonProperty]
        public int ContadorNroPreguntaActual { get; set; }
        [JsonProperty]
        public Pregunta PreguntaActual { get; set; }
        [JsonProperty]
        public List<Pregunta> ListaPreguntas { get; set; }
        [JsonProperty]
        public List<Respuesta> ListaRespuestas { get; set; }

        public Juego()
        {

        }
        private void InicializarJuego(string n)
        {
            Username = n;
            PuntajeActual = 0;
            CantidadPreguntasCorrectas = 0;
            ContadorNroPreguntaActual = 1;
            PreguntaActual = null;
            ListaPreguntas = null;
            ListaRespuestas = null;
        }
        public List<string> ObtenerCategorias()
        {
            List<string> AgregarC = new List<string>();
            Categoria c = new Categoria();
            for (int i = 0; i <= ListaPreguntas.Count(); i++)
            {
                if (AgregarC.Contains(c.Nombre))
                {
                    AgregarC.Add(c.Nombre);
                }
            }
            return AgregarC;
        }
        public void CargarPartida(string username, int categoria)
        {
            InicializarJuego(username);
            ListaPreguntas = BD.ObtenerPreguntas(categoria);
            ShufflePreguntas(ListaPreguntas);

            if (ListaPreguntas.Count == 20)
            {
                List<Pregunta> a = new List<Pregunta>();

                for (int i = 0; i < 20; i++)
                {
                    a.Add(ListaPreguntas[i]);
                }
                ListaPreguntas = a;
            }

            PreguntaActual = ListaPreguntas[0];
        }
        public Pregunta ObtenerProximaPregunta()
        {
            return PreguntaActual;
        }
        public List<Respuesta> ObtenerProximasRespuestas(int IDPregunta)
        {
            List<Respuesta> ProximasRespuestas = BD.ObtenerRespuestas(IDPregunta);
            return ProximasRespuestas;
        }
        public bool VerificarRespuesta(int IDRespuesta)
        {
            bool esCorrecta = false;

            foreach (Respuesta r in BD.ObtenerRespuestas(PreguntaActual.ID))
            {
                if (r.ID == IDRespuesta && r.Correcta)
                {
                    PuntajeActual += 1;
                    CantidadPreguntasCorrectas++;
                    esCorrecta = true;

                    if (ContadorNroPreguntaActual < ListaPreguntas.Count)
                    {
                        ContadorNroPreguntaActual++;
                        PreguntaActual = ListaPreguntas[ContadorNroPreguntaActual - 1];
                    }

                    break;

                }
            }


            return esCorrecta;

        }

        public bool verificarPreguntasRestantes()
        {
            bool a = true;

            if (ContadorNroPreguntaActual < ListaPreguntas.Count)
            {
                a = false;
            }

            return a;
        }

        public string RespCorrecta()
        {
            string a;

            foreach (Respuesta r in BD.ObtenerRespuestas(PreguntaActual.ID))
            {
                if (r.Correcta)
                {
                    a = r.Contenido;

                    return a;
                }
            }

            return "Bruno y Tobi los amo 🥰";

        }

        private static void ShufflePreguntas(List<Pregunta> Ps)
        {
            Random rng = new Random();
            int n = Ps.Count;

            for (int i = n - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);

                Pregunta r = Ps[i];
                Ps[i] = Ps[j];
                Ps[j] = r;
            }
        }

    }
}